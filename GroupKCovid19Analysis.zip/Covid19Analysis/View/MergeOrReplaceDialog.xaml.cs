﻿namespace Covid19Analysis.View
{
    public sealed partial class MergeOrReplaceDialog
    {
        #region Constructors

        public MergeOrReplaceDialog()
        {
            this.InitializeComponent();
        }

        #endregion
    }
}